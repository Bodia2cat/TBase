from tkinter import *
from tkinter import filedialog as fd
root = Tk()
mainmenu = Menu(root) 
root.config(menu=mainmenu)
root.title("TBase")
#=======================logic========================

def Save_as():
	file_name = fd.asksaveasfilename()
	text_to = text.get(1.0, END)
	handle = open(file_name, "w")
	handle.write(text_to)
	handle.close()

def MyGit():
	import webbrowser
	webbrowser.open("https://github.com/Bodia2cat")

def Help():
	webbrowser.open("http://192.168.0.118/t/help.html")

def Read_db():
	handle = open("db", "r")
	db_text = handle.read()
	text.insert(1.0, db_text)
	handle.close()
def Save_db():
	text_to = text.get(1.0, END)
	handle = open("db", "w")
	handle.write(text_to)
	handle.close()

def Any_db():
	name_db = fd.askopenfilename()
	handle = open(name_db, "r")
	db_text = handle.read()
	text.insert(1.0, db_text)
	handle.close()
#=======================objects===================
b_read = Button(text="Read")
b_save = Button(text="Save db")
text = Text()



#=====================pack======================
mainmenu.add_command(label='Save db', command=Save_db)
mainmenu.add_command(label='Save db as', command=Save_as)
mainmenu.add_command(label='Open db', command=Read_db)
mainmenu.add_command(label='Open db on computer', command=Any_db)
mainmenu.add_command(label='Github', command=MyGit)
mainmenu.add_command(label='Help', command=Help)
#b_save.pack()
#b_read.place(x=500, y=0)
text.pack()

root.mainloop()
#75 20