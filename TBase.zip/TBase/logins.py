Logins = ["Bodia", "Lolka"]
Passwords = ["ConyCony", "Kek"]