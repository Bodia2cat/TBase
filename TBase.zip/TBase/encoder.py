import os
import string
import sys
import random
try:
	if sys.argv[1]=="e":
		#names for decode from TBase
		size = 5
		name = ''.join(random.choice(string.ascii_letters) for _ in range(size))
		#write this name
		handle = open("names", "w")
		handle.write(name)
		handle.close()
		#encode
		os.rename("db", name + ".jpg")
	if sys.argv[1]=="d":
		#decode
		handle = open("names", "r")
		name = handle.read()
		handle.close()
		os.rename(name + ".jpg", "db")
except:
	exit()